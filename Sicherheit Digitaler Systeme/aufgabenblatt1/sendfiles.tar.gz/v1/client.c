#include <arpa/inet.h>
#include <dirent.h>
#include <fcntl.h>
#include <libgen.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "helper.h"

void usage() {
  fputs("Usage: ./client file\n", stderr);
  exit(EXIT_FAILURE);
}

void send_file(int fd, int sockfd, const char *filename) {
  byte_t fn_len = strlen(filename);
  if (write(sockfd, &fn_len, sizeof(byte_t)) < 1)
    ERROR("sending file len");
  if (write(sockfd, filename, fn_len) != fn_len)
    ERROR("sending filename");

  while (true) {
    char buf[BUF_LEN];
    int n = read(fd, buf, BUF_LEN);
    if (n == 0)
      return;

    if (write(sockfd, buf, n) < 0)
      ERROR("sending file content");
  }
}

int open_server_connection(const char *ip, const int port) {
  int sockfd = socket(AF_INET, SOCK_STREAM, 0);
  if (sockfd < 0)
    ERROR("socket");

  struct sockaddr_in server_addr;
  server_addr.sin_family = AF_INET;
  server_addr.sin_port = htons(port);
  server_addr.sin_addr.s_addr = inet_addr(ip);

  if (connect(sockfd, (struct sockaddr *)&server_addr, sizeof(server_addr)) ==
      -1)
    ERROR("connect");

  return sockfd;
}

int main(int args, char *argv[]) {
  if (args != 2)
    usage();

  char *filename = basename(argv[1]);
  if (strlen(filename) > MAX_FILENAME_LEN) {
    fprintf(stderr, "%s: %s\n", filename, strerror(ENAMETOOLONG));
    return ENAMETOOLONG;
  }

  int fd = open(argv[1], O_RDONLY);
  if (fd < 0)
    ERROR(argv[1]);

  int sockfd = open_server_connection(SERVER_IP, SERVER_PORT);
  send_file(fd, sockfd, filename);

  close(fd);
  close(sockfd);
}
