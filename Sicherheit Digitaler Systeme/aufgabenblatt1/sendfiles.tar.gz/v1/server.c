#include <arpa/inet.h>
#include <fcntl.h>
#include <libgen.h>
#include <pthread.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

#include "helper.h"

void write_file(int sockfd) {
  byte_t fn_len;

  int n = read(sockfd, &fn_len, sizeof(byte_t));
  if (n != sizeof(byte_t)) {
    WARN("reading filename len failed");
    return;
  }
#ifdef DEBUG
  printf("Filename length: %d\n, fn_len");
#endif

  char buf[BUF_LEN];
  n = read(sockfd, buf, fn_len);
  if (n != fn_len) {
    WARN("reading filename failed");
    return;
  }
  buf[n] = '\0';
  char *filename = basename(buf);
#ifdef DEBUG
  printf("Filename: %s\n, filename");
#endif

  int fd = open(filename, O_CREAT | O_WRONLY | O_EXCL, 0664);
  if (fd < 0) {
    WARN(filename);
    return;
  }

  while (true) {
    n = read(sockfd, buf, BUF_LEN);
    if (n <= 0)
      break;
    if (write(fd, buf, n) != n) {
      WARN("writing file content failed");
      break;
    }
  }
  close(fd);
}

void *client_handler(void *sockfd) {
  int *socket = sockfd;
  write_file(*socket);

  close(*socket);
  free(sockfd);
  return NULL;
}

int open_server_socket(const char *ip, int port) {
  int sockfd = socket(AF_INET, SOCK_STREAM, 0);
  if (sockfd < 0)
    ERROR("socket");

  struct sockaddr_in server_addr;
  bzero(&server_addr, sizeof(server_addr));
  server_addr.sin_family = AF_INET;
  server_addr.sin_port = htons(port);
  server_addr.sin_addr.s_addr = inet_addr(ip);

  if (bind(sockfd, (struct sockaddr *)&server_addr,
           sizeof(struct sockaddr_in)) != 0)
    ERROR("bind");

  if (listen(sockfd, 10) != 0)
    ERROR("listen");
  return sockfd;
}

int main() {
  int sockfd = open_server_socket(SERVER_IP, SERVER_PORT);

#ifndef DEBUG
  if (daemon(true, true) == -1)
    ERROR("daemon");
#endif

  pthread_t t;
  struct sockaddr_in new_addr;
  while (true) {
    socklen_t addr_size = sizeof(new_addr);
    int *sockp = malloc(sizeof(int));
    *sockp = accept(sockfd, (struct sockaddr *)&new_addr, &addr_size);

    if (pthread_create(&t, NULL, client_handler, sockp))
      WARN("pthread_create");
    pthread_detach(t);
  }
}
